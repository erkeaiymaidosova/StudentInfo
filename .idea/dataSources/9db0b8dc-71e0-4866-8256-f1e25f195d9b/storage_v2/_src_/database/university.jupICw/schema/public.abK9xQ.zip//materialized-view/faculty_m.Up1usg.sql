create materialized view faculty_m as
SELECT i.id,
       i.name,
       i.dept_name
FROM instructor i;

alter materialized view faculty_m owner to postgres;

