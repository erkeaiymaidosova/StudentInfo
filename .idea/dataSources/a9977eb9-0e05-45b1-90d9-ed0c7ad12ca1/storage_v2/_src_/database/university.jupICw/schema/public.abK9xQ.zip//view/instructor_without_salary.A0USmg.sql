create view instructor_without_salary(id, name, dept_name) as
SELECT instructor.id,
       instructor.name,
       instructor.dept_name
FROM instructor;

alter table instructor_without_salary
    owner to postgres;

