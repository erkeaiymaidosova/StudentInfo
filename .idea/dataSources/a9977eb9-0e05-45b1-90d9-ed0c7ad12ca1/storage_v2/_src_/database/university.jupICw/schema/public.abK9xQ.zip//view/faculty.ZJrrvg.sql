create view faculty(id, name, dept_name) as
SELECT i.id,
       i.name,
       i.dept_name
FROM instructor i;

alter table faculty
    owner to postgres;

